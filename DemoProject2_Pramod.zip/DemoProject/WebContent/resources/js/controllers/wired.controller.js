(function(){
	angular.module('Ecommerce').controller('WiredController',WiredController);
	
	WiredController.$inject=['$state','$stateParams'];
	
	function WiredController($state){
		var vm=this;
		vm.checkout=function(id){
			$state.go('checkout', {productId: id});
		};	
	};
})();