(function(){
	angular.module('Ecommerce').controller('HomeController',HomeController);
	
	HomeController.$inject=[];
	
	function HomeController(){
		
	};
})();