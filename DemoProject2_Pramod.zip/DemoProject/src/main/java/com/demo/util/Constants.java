package com.demo.util;

import java.util.ArrayList;
import java.util.List;

import com.demo.att.model.Device;

public class Constants {

	
}
