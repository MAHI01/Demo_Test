package com.demo.att.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/")
public class DeviceController {
	
	@RequestMapping(value="/shop/wireless/devices/" , method = RequestMethod.GET)
	public String getHomePage(ModelMap model) {
		model.addAttribute("message", "ATT Demo Project!");
		return "smartphones";
	}

}
