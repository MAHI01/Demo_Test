CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(1) NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `username` (`userName`)
) ENGINE=MyISAM AUTO_INCREMENT=51691598 DEFAULT CHARSET=utf8;


CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `country` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `active` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=51691598 DEFAULT CHARSET=utf8;


CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `device` (
  `deviceId` varchar(20) NOT NULL,
  `deviceName` varchar(200) DEFAULT NULL,
  `desciption` varchar(200) DEFAULT NULL,
  `configuration` varchar(200) NOT NULL,
  `colors` varchar(50) DEFAULT NULL,
  `price` int(11) NOT NULL,
  `imgSource` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`deviceId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `cart` (
  `cartId` int(14) NOT NULL AUTO_INCREMENT,
  `userid` varchar(11) NOT NULL,
  `deviceId` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`cartId`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;


