package com.demo.att.service.impl;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.demo.att.dao.CartDao;
import com.demo.att.model.Cart;
import com.demo.att.model.CartDetails;

@RunWith(MockitoJUnitRunner.class)
public class CartServiceImplTest {

	@InjectMocks
	CartServiceImpl cartServiceImpl;

	@Mock
	private CartDao cartDao;

	@Mock
	private Cart cart;

	@Mock
	private List<CartDetails> CartDetailsList;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void addCartTest() {
		Mockito.doNothing().when(cartDao).addCart(cart);
		cartServiceImpl.addCart(cart);
	}

	@Test
	public void getCartDetailsTest() {
		Mockito.when(cartDao.getCartDetails(Mockito.anyString())).thenReturn(
				CartDetailsList);
		cartServiceImpl.getCartDetails("userId");

	}

	@Test
	public void removeCartTest() {
		Mockito.when(cartDao.removeCart(cart)).thenReturn(Boolean.TRUE);
		cartServiceImpl.removeCart(cart);
	}

}
