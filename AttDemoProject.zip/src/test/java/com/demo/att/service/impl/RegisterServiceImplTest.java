package com.demo.att.service.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import com.demo.att.controller.RegisterController;
import com.demo.att.dao.LoginDao;
import com.demo.att.dao.RegisterDao;
import com.demo.att.model.Login;
import com.demo.att.model.Profile;
import com.demo.att.service.RegisterService;

public class RegisterServiceImplTest {
	
	@InjectMocks
	RegisterServiceImpl registerServiceImpl;
	
	@Mock 
	RegisterService registerService;
	
	@Mock
	RegisterController registerController;
	
	@Mock 
	RegisterDao registerDao;
	
	@Mock
	Profile profile;
	
	@Mock
	Session session;
	
	@Mock
	Login login;
	
	@Mock
	SessionFactory sessionFactory;
	
	@Mock
	Criteria crit;
	
	@Mock
	LoginDao loginDao;	
	
	@Mock
	BindingResult result;
	
	@Mock
	ModelMap model;
		
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test 
	public void registerUserTest(){		
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
		Mockito.when(profile.getUsername()).thenReturn("Jai");		
		registerServiceImpl.registerUser(profile);			
	}

}
