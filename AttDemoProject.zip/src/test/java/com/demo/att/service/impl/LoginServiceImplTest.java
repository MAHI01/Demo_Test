package com.demo.att.service.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import com.demo.att.dao.LoginDao;
import com.demo.att.dao.impl.LoginDaoImpl;
import com.demo.att.model.Login;
import com.demo.att.model.Profile;
import com.demo.att.service.LoginService;

public class LoginServiceImplTest {

	@InjectMocks
	LoginServiceImpl loginServiceImpl;

	@Mock
	LoginService loginService;

	@Mock
	Logger logger;

	@Mock
	LoginDao loginDao;

	@Mock
	Profile profile;

	@Mock
	Login login;

	@Mock
	Criteria crit;

	@Mock
	Session session;

	@Mock
	LoginDaoImpl loginDaoImpl;

	@Mock
	SessionFactory sessionFactory;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getUserProfileTest() {
		Mockito.when(loginDao.getUserProfile(login)).thenReturn(profile);
		loginServiceImpl.getUserProfile(login);
	}

	@Test
	public void getUserProfileByUserNameTest() {
		Mockito.when(loginDao.getUserProfileByUserName("jai")).thenReturn(profile);
		loginServiceImpl.getUserProfileByUserName("jai");

	}

}
