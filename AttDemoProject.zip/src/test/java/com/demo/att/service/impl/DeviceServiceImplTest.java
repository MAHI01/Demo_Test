package com.demo.att.service.impl;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.demo.att.dao.DeviceDao;
import com.demo.att.model.Device;

@RunWith(MockitoJUnitRunner.class)
public class DeviceServiceImplTest {

	@InjectMocks
	private DeviceServiceImpl deviceServiceImpl;

	@Mock
	private DeviceDao deviceDao;

	@Mock
	private List<Device> deviceList;

	@Mock
	private Device device;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getDeviceListTest() {
		Mockito.when(deviceDao.getDeviceList()).thenReturn(deviceList);
		deviceServiceImpl.getDeviceList();
	}

	@Test
	public void getDeviceDetailsTest() {
		Mockito.when(deviceDao.getDeviceDetails(Mockito.anyString()))
				.thenReturn(device);
		deviceServiceImpl.getDeviceDetails("deviceId");

	}

}
