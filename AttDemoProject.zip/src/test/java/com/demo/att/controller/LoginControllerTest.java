package com.demo.att.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;

import com.demo.att.model.Login;
import com.demo.att.model.Profile;
import com.demo.att.service.LoginService;

import junit.framework.Assert;

@SuppressWarnings("deprecation")
@RunWith(MockitoJUnitRunner.class)
public class LoginControllerTest {

	@InjectMocks
	LoginController loginController;	

	@Mock
	Login login;
	
	@Mock
	LoginService loginService;
	
	@Mock
	MessageSource messageSource;	
	
	@Mock
	Profile profile;
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}	

	@Test	
	public void listUsersTest() {
		Mockito.when(login.getUsername()).thenReturn("JP");
		Mockito.when(login.getPassword()).thenReturn("jp");
		Mockito.when(loginService.getUserProfile(login)).thenReturn(profile);
		Assert.assertEquals(profile,loginController.listUsers(login));
	}
}
