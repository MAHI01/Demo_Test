package com.demo.att.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.demo.att.model.Device;
import com.demo.att.service.DeviceService;

@RunWith(MockitoJUnitRunner.class)
public class DeviceControllerTest {

	@InjectMocks
	private DeviceController deviceController;

	@Mock
	private DeviceService deviceService;

	@Mock
	private List<Device> devicesList;

	@Mock
	private Device device;

	@Mock
	private HttpServletRequest httpServletRequest;

	private static final String MOCK_DEVICE_ID = "SKU001";

	@Before
	public void setUp() {

	}

	@Test
	public void getDeviceListTest() {
		Mockito.when(deviceService.getDeviceList()).thenReturn(devicesList);
		Assert.assertNotNull(deviceController.getDeviceList(httpServletRequest));
	}

	@Test
	public void getDeviceDetailsTest() {
		Mockito.when(deviceService.getDeviceDetails(Mockito.anyString()))
				.thenReturn(device);
		Assert.assertEquals(deviceController.getDeviceDetails(MOCK_DEVICE_ID),
				device);

	}
}
