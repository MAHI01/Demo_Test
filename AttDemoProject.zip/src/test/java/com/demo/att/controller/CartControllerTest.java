package com.demo.att.controller;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.HibernateException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

import com.demo.att.model.Cart;
import com.demo.att.model.CartDetails;
import com.demo.att.model.Device;
import com.demo.att.model.ResponseObject;
import com.demo.att.service.CartService;
import com.demo.att.service.DeviceService;
import com.demo.att.util.Constants;

@RunWith(MockitoJUnitRunner.class)
public class CartControllerTest {

	@InjectMocks
	CartController cartController;

	/*
	 * @Spy List<Cart> cartDetails;
	 */

	@Mock
	private CartService cartService;

	@Mock
	private CartDetails cartDetails;

	@Mock
	private MessageSource messageSource;

	@Mock
	private Cart cart;

	@Mock
	private HttpServletRequest request;

	@Mock
	private ResponseObject responseObject;

	@Mock
	private List<CartDetails> deviceDetail;

	@Mock
	private HttpSession httpSession;

	@Mock
	private DeviceService deviceService;

	@Mock
	private Device device;

	@Mock
	private Iterator<CartDetails> cartsIterator;

	@Mock
	private Iterator<CartDetails> cartsIteratorSession;

	@Mock
	private List<CartDetails> deviceDetailSession;

	@Before
	public void setUp() {

	}

	@Test
	public void addCartTest() {
		Mockito.when(cart.getUserId()).thenReturn("test");
		Mockito.when(cart.getDeviceId()).thenReturn("1001");
		Mockito.when(cart.getQuantity()).thenReturn(200);
		Mockito.doNothing().when(cartService).addCart(cart);
		Assert.assertEquals(cartController.addCart(cart, request).getStatus(),
				HttpStatus.OK);
	}

	@Test
	public void addCartTestException() {
		Mockito.when(cart.getUserId()).thenReturn("test");
		Mockito.when(cart.getDeviceId()).thenReturn("1001");
		Mockito.when(cart.getQuantity()).thenReturn(200);
		Mockito.doThrow(new HibernateException("Tsest Not found"))
				.when(cartService).addCart(cart);
		cartController.addCart(cart, request);
	}

	@Test
	public void addCartTestIDEmpty() throws Exception {
		String deviceId = "12344";
		Mockito.when(cart.getUserId()).thenReturn("");
		Mockito.when(cart.getDeviceId()).thenReturn(deviceId);
		Mockito.when(cart.getQuantity()).thenReturn(200);
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(deviceService.getDeviceDetails(deviceId)).thenReturn(
				device);
		Mockito.when(device.getDeviceId()).thenReturn("123");
		Mockito.when(device.getDeviceName()).thenReturn("nokia");
		Mockito.when(device.getDesciption()).thenReturn("123");
		Mockito.when(device.getConfiguration()).thenReturn("123");
		Mockito.when(device.getPrice()).thenReturn(12.9);
		Mockito.when(device.getDeviceId()).thenReturn("123");
		Mockito.when(device.getPrice()).thenReturn(12.9);
		Mockito.when(device.getImgSource()).thenReturn("");
		Assert.assertEquals(cartController.addCart(cart, request).getStatus(),
				HttpStatus.OK);
	}

	@Test
	public void addDevicesToSessionTest() {
		Mockito.when(cart.getDeviceId()).thenReturn("deviceId");

		Mockito.when(request.getSession()).thenReturn(httpSession);

		Mockito.when(
				request.getSession()
						.getAttribute(Constants.SESSION_DEVICE_ATTR))
				.thenReturn(deviceDetail).thenReturn(deviceDetailSession);

		Mockito.when(device.getDeviceId()).thenReturn("deviceId");

		Mockito.when(deviceDetail.iterator()).thenReturn(cartsIterator);

		Mockito.when(cartsIterator.hasNext()).thenReturn(Boolean.TRUE,
				Boolean.FALSE);

		Mockito.when(cartsIterator.next()).thenReturn(cartDetails);

		Mockito.when(cartDetails.getDeviceId()).thenReturn("deviceId");

		Mockito.when(deviceService.getDeviceDetails("deviceId")).thenReturn(
				device);

		Mockito.when(deviceDetailSession.iterator()).thenReturn(
				cartsIteratorSession);

		Mockito.when(cartsIteratorSession.hasNext()).thenReturn(Boolean.TRUE,
				Boolean.FALSE);

		Mockito.when(cartsIteratorSession.next()).thenReturn(cartDetails);

		Mockito.when(cartDetails.getDeviceId()).thenReturn("deviceId");

		cartController.addCart(cart, request);
	}

	@Test
	public void setDevicesInSessionTest() {
		Mockito.when(cart.getDeviceId()).thenReturn("deviceId");
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(
				request.getSession()
						.getAttribute(Constants.SESSION_DEVICE_ATTR))
				.thenReturn(deviceDetail);

		Mockito.when(device.getDeviceId()).thenReturn("deviceId");

		Mockito.when(deviceDetail.iterator()).thenReturn(cartsIterator);

		Mockito.when(cartsIterator.hasNext()).thenReturn(Boolean.TRUE,
				Boolean.FALSE);

		Mockito.when(cartsIterator.next()).thenReturn(cartDetails);

		cartController.addCart(cart, request);
	}

	@Test
	public void viewCartTest() {
		Mockito.when(cart.getUserId()).thenReturn("test");
		Mockito.when(cartService.getCartDetails("test")).thenReturn(
				deviceDetail);
		cartController.viewCart(cart, request);
	}

	@Test
	public void viewCartFromSessionTest() {
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(
				request.getSession()
						.getAttribute(Constants.SESSION_DEVICE_ATTR))
				.thenReturn(deviceDetail);
		Mockito.when(cartDetails.getDeviceId()).thenReturn("deviceId");

		Mockito.when(deviceDetail.iterator()).thenReturn(cartsIterator);

		Mockito.when(cartsIterator.hasNext()).thenReturn(Boolean.TRUE,
				Boolean.FALSE);

		Mockito.when(cartsIterator.next()).thenReturn(cartDetails);
		cartController.viewCart(cart, request);
	}

	@Test
	public void emptyCartTest() throws Exception {
		Cart cart = null;
		Assert.assertNotEquals(cartController.addCart(cart, request)
				.getStatus(), HttpStatus.OK);
	}

	@Test
	public void removeCartTest() {
		Mockito.when(cart.getUserId()).thenReturn("userId");
		Mockito.when(cartService.removeCart(cart)).thenReturn(Boolean.TRUE);
		cartController.removeCart(cart, request);
	}

	@Test
	public void removeCartFromSessionTest() {
		Mockito.when(cart.getDeviceId()).thenReturn("deviceId");
		Mockito.when(request.getSession()).thenReturn(httpSession);
		Mockito.when(
				request.getSession()
						.getAttribute(Constants.SESSION_DEVICE_ATTR))
				.thenReturn(deviceDetail);
		Mockito.when(cartDetails.getDeviceId()).thenReturn("deviceId");

		Mockito.when(deviceDetail.iterator()).thenReturn(cartsIterator);

		Mockito.when(cartsIterator.hasNext()).thenReturn(Boolean.TRUE,
				Boolean.FALSE);

		Mockito.when(cartsIterator.next()).thenReturn(cartDetails);

		// Mockito.when(cartsIterator.next().getDeviceId()).thenReturn("deviceId");

		cartController.removeCart(cart, request);
	}

	@Test
	public void removeEmptyCartTest() {
		Assert.assertEquals(cartController.removeCart(null, request)
				.getStatus(), HttpStatus.NOT_MODIFIED);
	}

	@Test
	public void removeCartExceptionTest() throws HibernateException {
		Mockito.when(cart.getUserId()).thenReturn("userId");
		Mockito.doThrow(new HibernateException("exception")).when(cartService)
				.removeCart(cart);
		Assert.assertEquals(cartController.removeCart(cart, request)
				.getMessage(), "exception");
	}

}
