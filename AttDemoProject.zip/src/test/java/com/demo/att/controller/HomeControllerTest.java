package com.demo.att.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.ui.ModelMap;

@RunWith(MockitoJUnitRunner.class)
public class HomeControllerTest {
	@InjectMocks
	private HomeController homeController;

	@Mock
	private ModelMap model;

	@Test
	public void getHomePageTest() {
		homeController.getHomePage(model);
	}
}
