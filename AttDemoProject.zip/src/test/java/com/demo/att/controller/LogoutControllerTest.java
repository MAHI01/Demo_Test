package com.demo.att.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@RunWith(PowerMockRunner.class)
public class LogoutControllerTest {

	@InjectMocks
	LogoutController logoutController;
	@Mock
	HttpServletRequest req;
	@Mock
	HttpServletResponse resp;
	@Mock
	SecurityContext context;
	@Mock
	Authentication authentication;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	@PrepareForTest(SecurityContextHolder.class)
	public void logoutPageTest() {
		PowerMockito.mockStatic(SecurityContextHolder.class);
		PowerMockito.when(SecurityContextHolder.getContext()).thenReturn(
				context);
		PowerMockito.when(context.getAuthentication()).thenReturn(
				authentication);
		Assert.assertEquals("redirect:/index",
				logoutController.logoutPage(req, resp));
	}
}
