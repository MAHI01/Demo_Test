package com.demo.att.controller;

import org.hibernate.HibernateException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.MessageSource;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import com.demo.att.model.Profile;
import com.demo.att.model.ResponseObject;
import com.demo.att.service.LoginService;
import com.demo.att.service.RegisterService;

@RunWith(MockitoJUnitRunner.class)
public class RegisterControllerTest {

	@InjectMocks
	RegisterController registerController;

	@Mock
	ResponseObject responseObject;

	@Mock
	Profile profile;

	@Mock
	BindingResult result;

	@Mock
	ModelMap model;

	@Mock
	ResponseObject response;

	@Mock
	RegisterService registerService;

	@Mock
	LoginService loginService;

	@Mock
	MessageSource messageSource;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void listUsersTest() {
		Mockito.when(profile.getUsername()).thenReturn("Jai");
		Mockito.when(loginService.getUserProfileByUserName(Mockito.anyString())).thenReturn(profile);
		registerController.listUsers(profile, result, model);
	}

	@Test
	public void listUsersNotAvailibilityTest() {
		Mockito.when(profile.getUsername()).thenReturn("Jai");
		registerController.listUsers(profile, result, model);
	}

	@Test
	public void listUsersTestForException() throws HibernateException {
		Mockito.when(profile.getUsername()).thenReturn("Jai");
		Mockito.doThrow(new HibernateException("exception")).when(registerService).registerUser(profile);
		registerController.listUsers(profile, result, model);
	}

}