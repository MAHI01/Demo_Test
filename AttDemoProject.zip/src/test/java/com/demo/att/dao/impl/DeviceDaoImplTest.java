package com.demo.att.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.demo.att.model.Device;

@RunWith(MockitoJUnitRunner.class)
public class DeviceDaoImplTest {

	@InjectMocks
	private DeviceDaoImpl deviceDaoImpl;

	@Mock
	private Device device;

	@Mock
	private Session session;

	@Mock
	private SessionFactory sessionFactory;

	@Mock
	private Criteria criteria;

	@Mock
	private List<Device> devicesList;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getDeviceListTest() {
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
		Mockito.when(session.createCriteria(Device.class)).thenReturn(criteria);
		Mockito.when(criteria.list()).thenReturn(devicesList);
		deviceDaoImpl.getDeviceList();

	}

	@Test
	public void getDeviceDetailsTest() {
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
		Mockito.when(session.createCriteria(Device.class)).thenReturn(criteria);
		Mockito.when(criteria.uniqueResult()).thenReturn(device);
		deviceDaoImpl.getDeviceDetails("deviceId");

	}
}