package com.demo.att.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DoubleType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.demo.att.model.Cart;
import com.demo.att.model.CartDetails;

@RunWith(MockitoJUnitRunner.class)
public class CartDaoImplTest {

	@InjectMocks
	private CartDaoImpl cartDaoImpl;

	@Mock
	private Cart cart;

	@Mock
	private Query query;

	@Mock
	private SQLQuery sqlQuery;

	@Mock
	private List<CartDetails> cartDetailsList;

	@Mock
	private Session session;

	@Mock
	private SessionFactory sessionFactory;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void addCartTest() {
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
		Mockito.doNothing().when(session).persist(Cart.class);
		cartDaoImpl.addCart(cart);

	}

	@Test
	public void getCartDetailsTest() {
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);

		Mockito.when(session.createSQLQuery(Mockito.anyString())).thenReturn(
				sqlQuery);

		Mockito.when(sqlQuery.addScalar("userId", StringType.INSTANCE))
				.thenReturn(sqlQuery);

		Mockito.when(sqlQuery.addScalar("totalPrice", DoubleType.INSTANCE))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.addScalar("quantity", IntegerType.INSTANCE))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.addScalar("deviceId", StringType.INSTANCE))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.addScalar("deviceName", StringType.INSTANCE))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.addScalar("colors", StringType.INSTANCE))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.addScalar("desciption", StringType.INSTANCE))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.addScalar("configuration", StringType.INSTANCE))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.addScalar("price", DoubleType.INSTANCE))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.addScalar("imgSource", StringType.INSTANCE))
				.thenReturn(sqlQuery);

		Mockito.when(
				sqlQuery.setParameter(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(sqlQuery);

		Mockito.when(
				sqlQuery.setResultTransformer(Transformers
						.aliasToBean(CartDetails.class))).thenReturn(sqlQuery);

		Mockito.when(sqlQuery.list()).thenReturn(cartDetailsList);

		cartDaoImpl.getCartDetails("userId");

	}

	@Test
	public void removeCartTest() {
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
		Mockito.when(session.createSQLQuery(Mockito.anyString()))
				.thenReturn(sqlQuery);
		Mockito.when(
				sqlQuery.setParameter(Mockito.anyString(), Mockito.anyString()))
				.thenReturn(sqlQuery);
		Mockito.when(sqlQuery.executeUpdate()).thenReturn(1);
		cartDaoImpl.removeCart(cart);
	}
}