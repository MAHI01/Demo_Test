package com.demo.att.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.hibernate.mapping.PersistentClass;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;

import com.demo.att.dao.AbstractDao;
import com.demo.att.dao.LoginDao;
import com.demo.att.dao.RegisterDao;
import com.demo.att.model.Login;
import com.demo.att.model.Profile;

public class RegisterDaoImplTest {

	@InjectMocks
	RegisterDaoImpl registerDaoImpl;

	@Mock
	AbstractDao<Integer, Profile> abstractDao;

	@Mock
	RegisterDao registerDao;

	@Mock
	Logger logger;

	@Mock
	Session session;

	@Mock
	SessionFactory sessionFactory;

	@Mock
	Login login;

	@Mock
	LoggerFactory loggerFactory;

	@Mock
	Criteria criteria;

	@Mock
	LoginDao loginDao;

	@Mock
	Profile profile;

	@Mock
	PersistentClass persist;

	@Mock
	PersistentClass persistentClass;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getLoggerTest() {
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
		registerDaoImpl.registerUser(profile);
	}

}
