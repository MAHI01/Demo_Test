package com.demo.att.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.mapping.PersistentClass;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;

import com.demo.att.dao.AbstractDao;
import com.demo.att.dao.LoginDao;
import com.demo.att.model.Login;
import com.demo.att.model.Profile;

@RunWith(PowerMockRunner.class)
public class LoginDaoImplTest {

	@InjectMocks
	LoginDaoImpl loginDaoImpl;

	@Mock
	AbstractDao<Login, Profile> abstractDao;

	@Mock
	PersistentClass persist;

	@Mock
	PersistentClass persistentClass;

	@Mock
	Login login;

	@Mock
	LoginDao loginDao;

	@Mock
	Criteria crit;

	@Mock
	Profile profile;

	@Mock
	private Session session;

	@Mock
	SessionFactory sessionFactory;

	@Mock
	Criteria criteria;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getUserProfileTest() throws ClassNotFoundException {
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
		Mockito.when(session.createCriteria(Profile.class)).thenReturn(criteria);
		// Mockito.doNothing().when(session.createCriteria(Class.forName("org.hibernate.Criteria")));
		Mockito.when(login.getUsername()).thenReturn("Jai");
		Mockito.when(login.getPassword()).thenReturn("jaipass");
		Mockito.when(crit.uniqueResult()).thenReturn(profile);
		loginDaoImpl.getUserProfile(login);

	}
	
	@Test
	public void getUserProfileByUserNameTest () {
		Mockito.when(sessionFactory.getCurrentSession()).thenReturn(session);
		Mockito.when(session.createCriteria(Profile.class)).thenReturn(criteria);		
		Mockito.when(crit.uniqueResult()).thenReturn(profile);
		loginDaoImpl.getUserProfileByUserName("Jai");	

	}
}