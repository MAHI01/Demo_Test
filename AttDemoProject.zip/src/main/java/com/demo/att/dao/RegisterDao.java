package com.demo.att.dao;

import com.demo.att.model.Profile;

public interface RegisterDao {
	public void registerUser(Profile profile);
}
