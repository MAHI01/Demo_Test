package com.demo.att.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.demo.att.dao.AbstractDao;
import com.demo.att.dao.RegisterDao;
import com.demo.att.model.Profile;

@Repository("RegisterDao")
public class RegisterDaoImpl extends AbstractDao<Integer, Profile> implements
		RegisterDao {
	static final Logger logger = LoggerFactory.getLogger(RegisterDaoImpl.class);

	@Override
	public void registerUser(Profile profile) {
		persist(profile);
	}

}
