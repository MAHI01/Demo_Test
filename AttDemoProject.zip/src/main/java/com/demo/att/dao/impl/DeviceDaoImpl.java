package com.demo.att.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.demo.att.dao.AbstractDao;
import com.demo.att.dao.DeviceDao;
import com.demo.att.model.Device;

@Repository("deviceDao")
public class DeviceDaoImpl extends AbstractDao<String, Device> implements
		DeviceDao {

	@SuppressWarnings("unchecked")
	@Override
	public List<Device> getDeviceList() {

		Criteria criteria = createEntityCriteria();
		criteria.addOrder(Order.asc("deviceId"));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		List<Device> deviceList = (List<Device>) criteria.list();
		return deviceList;
	}

	@Override
	public Device getDeviceDetails(String deviceId) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("deviceId", deviceId));
		Device device = (Device) crit.uniqueResult();
		return device;
	}

}
