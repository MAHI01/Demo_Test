package com.demo.att.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.demo.att.dao.AbstractDao;
import com.demo.att.dao.LoginDao;
import com.demo.att.model.Login;
import com.demo.att.model.Profile;

@Repository("LoginDao")
public class LoginDaoImpl extends AbstractDao<Login, Profile> implements
		LoginDao {
	static final Logger logger = LoggerFactory.getLogger(LoginDaoImpl.class);

	@Override
	public Profile getUserProfile(Login login) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("username", login.getUsername()));
		crit.add(Restrictions.eq("password", login.getPassword()));
		Profile profile = (Profile) crit.uniqueResult();

		return profile;

	}

	@Override
	public Profile getUserProfileByUserName(String userName) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("username", userName));
		Profile profile = (Profile) crit.uniqueResult();
		return profile;

	}

}
