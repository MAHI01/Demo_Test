package com.demo.att.dao;

import com.demo.att.model.Login;
import com.demo.att.model.Profile;

public interface LoginDao {
	public Profile getUserProfile(Login login);

	public Profile getUserProfileByUserName(String userName);
}
