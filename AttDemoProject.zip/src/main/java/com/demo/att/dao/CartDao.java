package com.demo.att.dao;

import java.util.List;

import com.demo.att.model.Cart;
import com.demo.att.model.CartDetails;

public interface CartDao {
	public void addCart(Cart cart);

	public List<CartDetails> getCartDetails(String userId);

	public boolean removeCart(Cart cart);
}
