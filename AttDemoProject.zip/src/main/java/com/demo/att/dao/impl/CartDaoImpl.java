package com.demo.att.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.type.DoubleType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.demo.att.dao.AbstractDao;
import com.demo.att.dao.CartDao;
import com.demo.att.model.Cart;
import com.demo.att.model.CartDetails;

@Repository("CartDao")
public class CartDaoImpl extends AbstractDao<Integer, Cart> implements CartDao {

	@Override
	public void addCart(Cart cart) {
		persist(cart);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<CartDetails> getCartDetails(String userId) {

		Query query = getSession()
				.createSQLQuery(
						"select d.deviceId,d.deviceName,d.desciption,d.configuration,d.colors,d.imgSource,query1.userId,query1.quantity,d.price,(query1.quantity*d.price) totalPrice from device d join "
								+ " (select c.userId,c.deviceId,sum(quantity) as quantity from cart c join device d on c.deviceId = d.deviceId where c.userId=:userId group by c.userId,c.deviceId) as query1 on query1.deviceid = d.deviceid")
				.addScalar("userId", StringType.INSTANCE)
				.addScalar("totalPrice", DoubleType.INSTANCE)
				.addScalar("quantity", IntegerType.INSTANCE)
				.addScalar("deviceId", StringType.INSTANCE)
				.addScalar("deviceName", StringType.INSTANCE)
				.addScalar("colors", StringType.INSTANCE)
				.addScalar("desciption", StringType.INSTANCE)
				.addScalar("configuration", StringType.INSTANCE)
				.addScalar("price", DoubleType.INSTANCE)
				.addScalar("imgSource", StringType.INSTANCE)
				.setResultTransformer(
						Transformers.aliasToBean(CartDetails.class))
				.setParameter("userId", userId);

		List<CartDetails> cartDetails = (List<CartDetails>) query.list();

		return cartDetails;
	}

	@Override
	public boolean removeCart(Cart cart) {
		boolean isDeleteSuccess = false;
		int isDelete = getSession()
				.createSQLQuery(
						"Delete from Cart where userId=:userId and deviceId=:deviceId")
				.setParameter("userId", cart.getUserId())
				.setParameter("deviceId", cart.getDeviceId()).executeUpdate();

		if (isDelete > 0) {
			isDeleteSuccess = true;
		}

		return isDeleteSuccess;

	}
}
