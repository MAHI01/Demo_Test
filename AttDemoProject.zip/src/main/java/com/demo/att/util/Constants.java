package com.demo.att.util;

public class Constants {

	public static final String SESSION_DEVICE_ATTR = "deviceAttribute";
	public static final String PROPERTY_NAME_DATABASE_DRIVER = "db.driver";
	public static final String PROPERTY_NAME_DATABASE_PASSWORD = "db.password";
	public static final String PROPERTY_NAME_DATABASE_URL = "db.url";
	public static final String PROPERTY_NAME_DATABASE_USERNAME = "db.username";
	public static final String PROPERTY_NAME_HIBERNATE_DIALECT = "hibernate.dialect";
	public static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "hibernate.show_sql";
	public static final String PROPERTY_NAME_HIBERNATE_FORMAT_SQL = "hibernate.format_sql";
	public static final String PROPERTY_NAME_PACKAGE_TO_SCAN = "com.demo.att.model";
	public static final String BASE_PACKAGE_TO_SCAN = "com.demo.att";
	public static final String PROPERTIES_SOURCE = "classpath:properties/application.properties";
	public static final String MESSAGE_SOURCE = "message";

	public static final String VIEW_RESOLVER_PREFIX = "/resources/views/";
	public static final String VIEW_RESOLVER_SUFFIX = ".html";
	public static final String RESOURCE_RESOLVER = "/resources/**";
	public static final String RESOURCE_LOCATION = "/resources/";

}
