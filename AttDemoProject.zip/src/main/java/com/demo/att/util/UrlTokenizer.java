package com.demo.att.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import com.demo.att.model.User;

public class UrlTokenizer {

	private static String secret = "secret";

	public static String generateToken(User u) {
		Claims claims = Jwts.claims().setSubject(u.getSsoId());
		claims.put("userId", u.getId() + "");
		claims.put("email", u.getEmail());
		return Jwts.builder().setClaims(claims)
				.signWith(SignatureAlgorithm.HS256, secret).compact();
	}

	public static User parseToken(String token) {
		try {
			Claims body = Jwts.parser().setSigningKey(secret)
					.parseClaimsJws(token).getBody();
			User u = new User();
			u.setSsoId(body.getSubject());
			u.setId(Integer.parseInt((String) body.get("userId")));
			u.setEmail((String) body.get("email"));
			return u;
		} catch (JwtException | ClassCastException e) {
			return null;
		}
	}

}
