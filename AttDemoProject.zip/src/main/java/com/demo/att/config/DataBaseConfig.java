package com.demo.att.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.demo.att.util.Constants;

@Configuration
@EnableTransactionManagement
@ComponentScan(basePackages = Constants.BASE_PACKAGE_TO_SCAN)
@PropertySource(value = { Constants.PROPERTIES_SOURCE })
public class DataBaseConfig {

	@Autowired
	private Environment environment;

	@Bean
	public LocalSessionFactoryBean sessionFactory() {
		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory
				.setPackagesToScan(new String[] { Constants.PROPERTY_NAME_PACKAGE_TO_SCAN });
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;
	}

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environment
				.getRequiredProperty(Constants.PROPERTY_NAME_DATABASE_DRIVER));
		dataSource.setUrl(environment
				.getRequiredProperty(Constants.PROPERTY_NAME_DATABASE_URL));
		dataSource
				.setUsername(environment
						.getRequiredProperty(Constants.PROPERTY_NAME_DATABASE_USERNAME));
		dataSource
				.setPassword(environment
						.getRequiredProperty(Constants.PROPERTY_NAME_DATABASE_PASSWORD));
		return dataSource;
	}

	private Properties hibernateProperties() {
		Properties properties = new Properties();
		properties
				.put(Constants.PROPERTY_NAME_HIBERNATE_DIALECT,
						environment
								.getRequiredProperty(Constants.PROPERTY_NAME_HIBERNATE_DIALECT));
		properties
				.put(Constants.PROPERTY_NAME_HIBERNATE_SHOW_SQL,
						environment
								.getRequiredProperty(Constants.PROPERTY_NAME_HIBERNATE_SHOW_SQL));
		properties
				.put(Constants.PROPERTY_NAME_HIBERNATE_FORMAT_SQL,
						environment
								.getRequiredProperty(Constants.PROPERTY_NAME_HIBERNATE_FORMAT_SQL));
		return properties;
	}

	@Bean
	@Autowired
	public HibernateTransactionManager transactionManager(SessionFactory s) {
		HibernateTransactionManager txManager = new HibernateTransactionManager();
		txManager.setSessionFactory(s);
		return txManager;
	}
}
