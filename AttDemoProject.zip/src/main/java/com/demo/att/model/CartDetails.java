package com.demo.att.model;

public class CartDetails {
	private int cartId;

	private String userId;

	private double totalPrice;

	private int quantity;

	private String deviceId;

	private String deviceName;

	private String colors;

	private String desciption;

	private String configuration;

	private double price;

	private String imgSource;

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}

	public String getColors() {
		return colors;
	}

	public void setColors(String colors) {
		this.colors = colors;
	}

	public String getDesciption() {
		return desciption;
	}

	public void setDesciption(String desciption) {
		this.desciption = desciption;
	}

	public String getConfiguration() {
		return configuration;
	}

	public void setConfiguration(String configuration) {
		this.configuration = configuration;
	}

	public String getImgSource() {
		return imgSource;
	}

	public void setImgSource(String imgSource) {
		this.imgSource = imgSource;
	}

	@Override
	public String toString() {
		return "CartDetails [cartId=" + cartId + ", userId=" + userId
				+ ", totalPrice=" + totalPrice + ", quantity=" + quantity
				+ ", deviceId=" + deviceId + ", deviceName=" + deviceName
				+ ", colors=" + colors + ", desciption=" + desciption
				+ ", configuration=" + configuration + ", price=" + price
				+ ", imgSource=" + imgSource + "]";
	}

}
