package com.demo.att.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.att.dao.LoginDao;
import com.demo.att.model.Login;
import com.demo.att.model.Profile;
import com.demo.att.service.LoginService;

@Service("LoginService")
@Transactional
public class LoginServiceImpl implements LoginService {

	@Autowired
	LoginDao loginDao;

	@Override
	public Profile getUserProfile(Login login) {
		return loginDao.getUserProfile(login);
	}
	
	@Override
	public Profile getUserProfileByUserName(String userName) {
		return loginDao.getUserProfileByUserName(userName);
	}

}
