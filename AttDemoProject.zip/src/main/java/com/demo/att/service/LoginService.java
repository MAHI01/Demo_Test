package com.demo.att.service;

import com.demo.att.model.Login;
import com.demo.att.model.Profile;

public interface LoginService {
	public Profile getUserProfile(Login login);

	public Profile getUserProfileByUserName(String userName);

}
