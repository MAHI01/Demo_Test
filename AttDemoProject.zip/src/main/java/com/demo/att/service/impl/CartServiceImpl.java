package com.demo.att.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.att.dao.CartDao;
import com.demo.att.model.Cart;
import com.demo.att.model.CartDetails;
import com.demo.att.service.CartService;

@Service("cartService")
@Transactional
public class CartServiceImpl implements CartService {

	@Autowired
	CartDao cartDao;

	@Override
	public void addCart(Cart cart) {
		cartDao.addCart(cart);
	}

	@Override
	public List<CartDetails> getCartDetails(String userId) {
		return cartDao.getCartDetails(userId);
	}

	@Override
	public boolean removeCart(Cart cart) {
		return cartDao.removeCart(cart);

	}

}
