package com.demo.att.service;

import com.demo.att.model.Profile;

public interface RegisterService {
	public void registerUser(Profile profile);

}
