package com.demo.att.service;

import java.util.List;

import com.demo.att.model.Cart;
import com.demo.att.model.CartDetails;

public interface CartService {
	public void addCart(Cart cart);

	public List<CartDetails> getCartDetails(String userId);

	public boolean removeCart(Cart cart);
}
