package com.demo.att.service;

import java.util.List;

import com.demo.att.model.Device;

public interface DeviceService {
	public List<Device> getDeviceList();

	public Device getDeviceDetails(String deviceId);
}
