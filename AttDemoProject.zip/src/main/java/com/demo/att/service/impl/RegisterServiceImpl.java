package com.demo.att.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.att.dao.RegisterDao;
import com.demo.att.model.Profile;
import com.demo.att.service.RegisterService;

@Service("ResgisterService")
@Transactional
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	RegisterDao registerDao;

	@Override
	public void registerUser(Profile profile) {
		registerDao.registerUser(profile);
	}

}
