package com.demo.att.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.att.model.Profile;
import com.demo.att.model.ResponseObject;
import com.demo.att.service.LoginService;
import com.demo.att.service.RegisterService;

@RestController
@RequestMapping("/")
public class RegisterController {

	@Autowired
	RegisterService registerService;

	@Autowired
	LoginService loginService;

	@Autowired
	MessageSource messageSource;

	/**
	 * This method will authenticate user login.
	 */
	@RequestMapping(value = { "/registerUser" }, method = RequestMethod.POST)
	public ResponseObject listUsers(@RequestBody Profile profile, BindingResult result, ModelMap model) {
		String message = "";
		boolean isSaveSuccess = false;
		ResponseObject response = new ResponseObject();

		if (!StringUtils.isEmpty(profile) && !StringUtils.isEmpty(profile.getUsername())) {
			// profile.setPassword(passwordEncoder.encode(profile.getPassword()));

			if (isUserNameAvailable(profile.getUsername())) {
				try {
					registerService.registerUser(profile);
					isSaveSuccess = true;
				} catch (Exception e) {
					message = e.getMessage();
				}
			} else {
				message = messageSource.getMessage("non.unique.username", new String[] { profile.getUsername() },
						new Locale("de"));
			}
		}

		if (isSaveSuccess) {
			response.setStatus(HttpStatus.OK);
			response.setMessage(message);
		} else {
			response.setStatus(HttpStatus.NOT_MODIFIED);
			response.setMessage(message);
		}

		return response;

	}

	private boolean isUserNameAvailable(String userName) {
		boolean isUserNameAvailable = true;
		Profile profile = new Profile();
		profile = loginService.getUserProfileByUserName(userName);

		if (!StringUtils.isEmpty(profile) && !StringUtils.isEmpty(profile.getUsername())) {
			isUserNameAvailable = false;
		}

		return isUserNameAvailable;
	}
}
