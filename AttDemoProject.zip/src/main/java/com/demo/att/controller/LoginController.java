package com.demo.att.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.att.model.Login;
import com.demo.att.model.Profile;
import com.demo.att.service.LoginService;

@RestController
@RequestMapping("/")
public class LoginController {

	@Autowired
	LoginService loginService;

	@Autowired
	MessageSource messageSource;

	/**
	 * This method will authenticate user login.
	 */
	@RequestMapping(value = { "/validateLogin" }, method = RequestMethod.POST)
	public Profile listUsers(@RequestBody Login login) {

		Profile profile = new Profile();
		String userName = login.getUsername();
		String password = login.getPassword();

		if (!StringUtils.isEmpty(userName) && !StringUtils.isEmpty(password)) {
			// login.setPassword(passwordEncoder.encode(password));
			profile = loginService.getUserProfile(login);
		}
		return profile;
	}

}
