package com.demo.att.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.att.model.Cart;
import com.demo.att.model.CartDetails;
import com.demo.att.model.Device;
import com.demo.att.model.ResponseObject;
import com.demo.att.service.CartService;
import com.demo.att.service.DeviceService;
import com.demo.att.util.Constants;

@RestController
public class CartController {

	@Autowired
	private CartService cartService;

	@Autowired
	DeviceService deviceService;

	@Autowired
	MessageSource messageSource;

	@RequestMapping(value = "/shop/wireless/devices/cart/addDevice", method = RequestMethod.POST)
	public ResponseObject addCart(@RequestBody Cart cart,
			HttpServletRequest request) {

		boolean isSaveSuccess = false;
		ResponseObject response = new ResponseObject();
		String message = "";

		if (!StringUtils.isEmpty(cart)) {

			if (!StringUtils.isEmpty(cart.getUserId())) {
				try {
					cartService.addCart(cart);
					isSaveSuccess = true;
				} catch (Exception e) {
					message = e.getMessage();
				}
			} else {
				addDevicesToSession(request, cart.getDeviceId());
				isSaveSuccess = true;
			}

		} else {
			message = messageSource.getMessage("cart.is.empty.error", null,
					new Locale("de"));
		}
		if (isSaveSuccess) {
			response.setStatus(HttpStatus.OK);
			response.setMessage(message);
		} else {
			response.setStatus(HttpStatus.NOT_MODIFIED);
			response.setMessage(message);
		}

		return response;
	}

	private List<CartDetails> getCartDetails(String userId) {
		List<CartDetails> cartsList = new ArrayList<CartDetails>();
		cartsList = cartService.getCartDetails(userId);
		return cartsList;
	}

	@SuppressWarnings("unchecked")
	private List<CartDetails> addDevicesToSession(HttpServletRequest request,
			String deviceId) {
		List<CartDetails> devicesList = new ArrayList<CartDetails>();
		boolean isProductAdded = false;
		devicesList = (List<CartDetails>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);
		if (StringUtils.isEmpty(devicesList)) {
			setDevicesInSession(request, deviceId);
		} else {
			for (CartDetails device : devicesList) {
				String deviceIdAdded = device.getDeviceId();
				if (!StringUtils.isEmpty(deviceIdAdded)
						&& deviceIdAdded.equalsIgnoreCase(deviceId)) {
					isProductAdded = true;
				}
			}

			if (!isProductAdded) {
				setDevicesInSession(request, deviceId);
			} else {
				incrementQuantityInSession(request, deviceId);
			}

		}
		devicesList = (List<CartDetails>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);
		return devicesList;
	}

	@SuppressWarnings("unchecked")
	private List<CartDetails> getDevicesFromSession(HttpServletRequest request) {
		List<CartDetails> devicesList = new ArrayList<CartDetails>();
		devicesList = (List<CartDetails>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);
		return devicesList;
	}

	@SuppressWarnings("unchecked")
	private void setDevicesInSession(HttpServletRequest request, String deviceId) {
		List<CartDetails> devicesList = new ArrayList<CartDetails>();
		CartDetails details = new CartDetails();
		devicesList = (List<CartDetails>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);
		Device device = deviceService.getDeviceDetails(deviceId);
		if (StringUtils.isEmpty(devicesList)) {
			devicesList = new ArrayList<CartDetails>();
		}

		if (!StringUtils.isEmpty(device)) {
			details.setDeviceId(device.getDeviceId());
			details.setDeviceName(device.getDeviceName());
			details.setDesciption(device.getDesciption());
			details.setConfiguration(device.getConfiguration());
			details.setPrice(device.getPrice());
			details.setTotalPrice(device.getPrice());
			details.setQuantity(1);
			details.setImgSource(device.getImgSource());
		}

		devicesList.add(details);
		request.getSession().setAttribute(Constants.SESSION_DEVICE_ATTR,
				devicesList);
	}

	@SuppressWarnings("unchecked")
	private void incrementQuantityInSession(HttpServletRequest request,
			String deviceId) {
		List<CartDetails> devicesList = new ArrayList<CartDetails>();
		devicesList = (List<CartDetails>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);

		for (CartDetails device : devicesList) {
			String deviceIdAdded = device.getDeviceId();
			if (!StringUtils.isEmpty(deviceIdAdded)
					&& deviceIdAdded.equalsIgnoreCase(deviceId)) {

				int quantity = device.getQuantity() + 1;
				double price = device.getTotalPrice() * quantity;
				device.setQuantity(quantity);
				device.setTotalPrice(price);
			}
		}
		request.getSession().setAttribute(Constants.SESSION_DEVICE_ATTR,
				devicesList);
	}

	@RequestMapping(value = "/shop/wireless/devices/cart/view", method = RequestMethod.POST)
	public List<CartDetails> viewCart(@RequestBody Cart cart,
			HttpServletRequest request) {
		List<CartDetails> deviceList = getCartDetails(request, cart);
		return deviceList;
	}

	private List<CartDetails> getCartDetails(HttpServletRequest request,
			Cart cart) {
		List<CartDetails> deviceList = new ArrayList<CartDetails>();
		if (!StringUtils.isEmpty(cart)
				&& !StringUtils.isEmpty(cart.getUserId())) {
			deviceList = getCartDetails(cart.getUserId());
		} else {
			deviceList = getDevicesFromSession(request);

		}
		return deviceList;
	}

	@RequestMapping(value = "/shop/wireless/devices/cart/removeDevice", method = RequestMethod.POST)
	public ResponseObject removeCart(@RequestBody Cart cart,
			HttpServletRequest request) {

		boolean isDeleteSuccess = false;
		ResponseObject response = new ResponseObject();
		String message = "";

		if (!StringUtils.isEmpty(cart)) {

			if (!StringUtils.isEmpty(cart.getUserId())) {
				try {
					isDeleteSuccess = cartService.removeCart(cart);
				} catch (Exception e) {
					message = e.getMessage();
				}
			} else {
				removeDeviceFromSession(request, cart.getDeviceId());
				isDeleteSuccess = true;
			}

		} else {
			message = messageSource.getMessage("cart.is.empty.error", null,
					new Locale("de"));
		}
		if (isDeleteSuccess) {
			response.setStatus(HttpStatus.OK);
			response.setMessage(message);
		} else {
			response.setStatus(HttpStatus.NOT_MODIFIED);
			response.setMessage(message);
		}

		return response;
	}

	@SuppressWarnings("unchecked")
	private List<CartDetails> removeDeviceFromSession(
			HttpServletRequest request, String deviceId) {
		List<CartDetails> devicesList = new ArrayList<CartDetails>();
		devicesList = (List<CartDetails>) request.getSession().getAttribute(
				Constants.SESSION_DEVICE_ATTR);

		Iterator<CartDetails> cartsIterator = devicesList.iterator();

		while (cartsIterator.hasNext()) {
			CartDetails cartDetails = cartsIterator.next();

			if (StringUtils.endsWithIgnoreCase(cartDetails.getDeviceId(),
					deviceId)) {
				cartsIterator.remove();
			}
		}
		request.getSession().setAttribute(Constants.SESSION_DEVICE_ATTR,
				devicesList);
		return devicesList;
	}

}
