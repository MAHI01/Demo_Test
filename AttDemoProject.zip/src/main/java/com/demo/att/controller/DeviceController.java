package com.demo.att.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.att.model.Device;
import com.demo.att.service.DeviceService;

@RestController("deviceController")
@RequestMapping("/")
public class DeviceController {

	@Autowired
	DeviceService deviceService;

	@RequestMapping(value = "/shop/wireless/devices", method = RequestMethod.GET)
	public List<Device> getDeviceList(HttpServletRequest request) {
		List<Device> deviceList = deviceService.getDeviceList();
		return deviceList;
	}

	@RequestMapping(value = "/shop/wireless/devices/details", method = RequestMethod.GET)
	public Device getDeviceDetails(@RequestParam String deviceId) {
		Device deviceDetails = new Device();
		if (!StringUtils.isEmpty(deviceId) && !StringUtils.isEmpty(deviceId)) {
			deviceDetails = deviceService.getDeviceDetails(deviceId);
		}
		return deviceDetails;
	}
}
