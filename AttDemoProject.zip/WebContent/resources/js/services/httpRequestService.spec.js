describe('Http Request Service', function() {
	var getUrlRequest, $httpBackend;

	var mockedResponse = {
		'userId' : 'userX',
		'A-Token' : 'xxx'
	};

	beforeEach(angular.mock.module('Ecommerce'));

	beforeEach(inject(function(_getUrlRequest_, _$httpBackend_) {
		getUrlRequest = _getUrlRequest_;
		$httpBackend = _$httpBackend_;

		$httpBackend.when('GET', '/shop/wireless/devices').respond(
				mockedResponse);

		$httpBackend.when('POST', '/shop/wireless/devices').respond(
				mockedResponse);

	}));

	afterEach(function() {
		$httpBackend.verifyNoOutstandingExpectation();
		$httpBackend.verifyNoOutstandingRequest();
	});

	it('Service should be defined', function() {
		expect(getUrlRequest).toBeDefined();
	});

	describe('makeHttpCall method ', function() {
		it('should exist', function() {
			expect(getUrlRequest.makeHttpCall).toBeDefined();
		});

		it('POST Call success test', function() {
			getUrlRequest
					.makeHttpCall("/shop/wireless/devices", "POST", {}, {})
					.then(function(response) {
						expect(response.data.userId).toEqual("userX");
					});
			$httpBackend.flush();
		});
	});

	describe('makeHttpGetCall method ', function() {

		it('should exist', function() {
			expect(getUrlRequest.makeHttpGetCall).toBeDefined();
		});

		it('GET call test', function() {
			getUrlRequest.makeHttpGetCall("/shop/wireless/devices", "GET", {},
					{}).then(function(response) {
				expect(response.data.userId).toEqual("userX");
			});
			$httpBackend.flush();
		});
	});
});