(function() {
	angular.module('Ecommerce').service('getUrlRequest', getUrlRequest);

	getUrlRequest.$inject = [ '$http' ];

	function getUrlRequest($http) {
		this.makeHttpCall = function(url, method, params, header) {
			return $http({
				method : method,
				url : url,
				data : params,
				header : header
			}).then(function successCallback(response) {
				return response;
			}, function errorCallback(response) {
				return "error";
			});
		};

		this.makeHttpGetCall = function(url, method, params) {
			return $http({
				method : method,
				url : url,
				params : params
			}).then(function successCallback(response) {
				return response;
			}, function errorCallback(response) {
				return "error";
			});
		};
	}
	;

})();