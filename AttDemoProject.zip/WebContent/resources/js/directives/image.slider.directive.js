(function(){
	angular.module('Ecommerce').directive('imageSlider',imageSlider);
	
	imageSlider.$inject=['$interval'];
	
	function imageSlider($interval){
		return {
			restrict:'E',
			scope:{
				images:"=sliderImages"
			},
			templateUrl:'./resources/views/imageslider.html',
			link:function(scope,elem,attr,controller){
				scope.currentPosition=0;
				scope.loadNextImage=function(pos){
					if(scope.currentPosition == scope.images.length-1){
						scope.currentPosition=0;
					}else{
						scope.currentPosition+=1;
					};
				};
				scope.loadPreviousImage=function(pos){
					if(scope.currentPosition == 0){
						scope.currentPosition=scope.images.length-1;
					}else{
						scope.currentPosition-=1;
					};
				};
				$interval(scope.loadNextImage,2000);
			}
		};
	};
})();