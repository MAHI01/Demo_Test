describe("HeaderController Test", function() {

	var $controller, $window, $location, $state, getUrlRequest, $rootScope;

	var mockedResponse = {
		'userId' : 'userX',
		'A-Token' : 'xxx'
	};

	beforeEach(angular.mock.module("Ecommerce"));

	beforeEach(angular.mock.inject(function(_$window_, _$location_,
			_$httpBackend_, _$state_, _getUrlRequest_, _$rootScope_) {

		$window = _$window_;
		$location = _$location_;
		$httpBackend = _$httpBackend_;
		$state = _$state_;
		getUrlRequest = _getUrlRequest_;
		$rootScope = _$rootScope_;
		spyOn($state, 'go');
	}));

	beforeEach(inject(function(_$controller_) {
		$controller = _$controller_('HeaderController', {
			$window : $window,
			$location : $location,
			$state : $state,
			getUrlRequest : getUrlRequest,
			$rootScope : $rootScope
		});
	}));

	afterEach(function() {
		$httpBackend.verifyNoOutstandingExpectation();
		$httpBackend.verifyNoOutstandingRequest();
	});

	it('should logout', function() {

		$controller.logout();

		$httpBackend.when('POST', './logoutUser').respond(mockedResponse);

		getUrlRequest.makeHttpCall("./logoutUser", "POST", {}).then(
				function(response) {
					expect($state.go).toHaveBeenCalledWith('home', {}, {
						reload : true
					});
				});
		$httpBackend.flush();
	});

	it('should set user in Header', function() {
		$window.sessionStorage.setItem("loginUser", "admin");
		$rootScope.$emit("SetUserInHeader", {});
	});

	it('should HideHeader', function() {
		$rootScope.$emit("HideHeader", {});
	});

	it('should ShowHeader', function() {
		$rootScope.$emit("ShowHeader", {});
	});

});