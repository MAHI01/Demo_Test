(function() {
	angular.module('Ecommerce').controller('CheckoutController',
			CheckoutController);

	CheckoutController.$inject = [ 'getUrlRequest', '$window', '$state' ];

	function CheckoutController(getUrlRequest, $window, $state) {
		var vm = this;
		vm.showHeader = true;
		// var userId = $stateParams.userId;
		var userId = $window.sessionStorage.getItem("loginUser");
		vm.productDetails = '';
		var url = "./shop/wireless/devices/cart/view";
		var method = "POST";
		var params = {
			"userId" : userId
		};
		var headers = {
			"Content-Type" : "application/JSON",
			"X-Login-Ajax-call" : 'true'
		};
		getUrlRequest.makeHttpCall(url, method, params, headers).then(
				function(resp) {
					vm.cartDetails = resp.data;
				});

		vm.removeFromCart = function(deviceId) {
			var userId = $window.sessionStorage.getItem("loginUser");
			vm.productDetails = '';
			var url = "./shop/wireless/devices/cart/removeDevice";
			var method = "POST";
			var params = {
				"userId" : userId,
				"deviceId" : deviceId
			};
			var headers = {
				"Content-Type" : "application/JSON",
				"X-Login-Ajax-call" : 'true'
			};
			getUrlRequest.makeHttpCall(url, method, params, headers).then(
					function(resp) {
						$state.reload();
					});

		};
	}
	;
})();