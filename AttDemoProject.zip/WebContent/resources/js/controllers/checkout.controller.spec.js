describe("CheckoutController Test", function() {

	var $controller, $state, getUrlRequest, $httpBackend, $window;

	var mockedResponse = {
		'userId' : 'userX',
		'A-Token' : 'xxx'
	};

	beforeEach(angular.mock.module("Ecommerce"));

	beforeEach(angular.mock.inject(function(_$state_, _getUrlRequest_,
			_$httpBackend_, _$window_) {
		$state = _$state_;
		getUrlRequest = _getUrlRequest_;
		$httpBackend = _$httpBackend_;
		$window = _$window_;
		spyOn($state, 'go');
	}));

	beforeEach(inject(function(_$controller_) {
		$controller = _$controller_('CheckoutController', {
			$state : $state,
			getUrlRequest : getUrlRequest,
			$httpBackend : $httpBackend,
			$window : $window
		});
	}));

	afterEach(function() {
		$httpBackend.verifyNoOutstandingExpectation();
		$httpBackend.verifyNoOutstandingRequest();
	});

	it('should fetch checkout view', function() {
		$httpBackend.when('POST', './shop/wireless/devices/cart/view').respond(
				mockedResponse);

		getUrlRequest.makeHttpCall("./shop/wireless/devices/cart/view", "POST",
				{}).then(function(response) {
			expect(response.data.userId).toEqual("userX");
		});
		$httpBackend.flush();
	});

	it('should test removeFromCart', function() {
		$controller.removeFromCart("SKU001");

		$httpBackend.when('POST', './shop/wireless/devices/cart/removeDevice')
				.respond(mockedResponse);

		getUrlRequest.makeHttpCall("./shop/wireless/devices/cart/addDevice",
				"POST", {}).then(function(response) {
			expect($state.reload);
		});
		$httpBackend.flush();
	});

});