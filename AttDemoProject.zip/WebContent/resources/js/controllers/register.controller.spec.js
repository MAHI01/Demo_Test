describe("RegisterController Test", function() {

	var $controller, $state, getUrlRequest, $httpBackend, $window, $rootScope;

	var mockedResponse = {
		'status' : 'OK'
	};

	var mockedResponseFail = {
		'status' : 'ERROR'
	};

	beforeEach(angular.mock.module("Ecommerce"));

	beforeEach(angular.mock.inject(function(_$state_, _getUrlRequest_,
			_$httpBackend_, _$window_, _$rootScope_) {
		$state = _$state_;
		getUrlRequest = _getUrlRequest_;
		$httpBackend = _$httpBackend_;
		$window = _$window_;
		$rootScope = _$rootScope_;
		spyOn($state, 'go');
	}));

	beforeEach(inject(function(_$controller_) {
		$controller = _$controller_('RegisterController', {
			$state : $state,
			getUrlRequest : getUrlRequest,
			$httpBackend : $httpBackend,
			$window : $window,
			$rootScope : $rootScope
		});
	}));

	afterEach(function() {
		$httpBackend.verifyNoOutstandingExpectation();
		$httpBackend.verifyNoOutstandingRequest();
	});

	it('should test registration', function() {
		$controller.register();

		$httpBackend.when('POST', './registerUser').respond(mockedResponse);

		getUrlRequest.makeHttpCall("./registerUser", "POST", {}).then(
				function(response) {
					expect($state.go).toHaveBeenCalledWith('login', {}, {
						reload : true
					});

				});
		$httpBackend.flush();
	});

	it('should test failed registration',
			function() {
				$controller.register();

				$httpBackend.when('POST', './registerUser').respond(
						mockedResponseFail);

				getUrlRequest.makeHttpCall("./registerUser", "POST", {}).then(
						function(response) {
							

						});
				$httpBackend.flush();
			});

});