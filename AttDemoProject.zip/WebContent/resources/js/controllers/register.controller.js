(function() {
	angular.module('Ecommerce').controller('RegisterController',
			RegisterController);

	RegisterController.$inject = [ '$state', 'getUrlRequest', '$http',
			'$window', '$rootScope' ];

	function RegisterController($state, getUrlRequest, $http, $window,
			$rootScope) {
		var vm = this;
		vm.showLoaderIndicator = true;
		vm.showHeader = false;
		vm.invalidLogin = false;
		vm.invalidRegistration = false;
		vm.validRegistration = false;

		$rootScope.$emit("HideHeader", {});

		vm.register = function() {
			var method = 'POST';
			var url = './registerUser';
			var params = {
				"username" : vm.username,
				'email' : vm.email,
				'password' : vm.password,
				'firstname' : vm.firstname,
				'lastname' : vm.lastname,
				'gender' : vm.gender,
				'country' : vm.country,
				'dob' : vm.dob,
				'active' : 'Y'

			};

			var headers = {
				"Content-Type" : "application/JSON",
				"X-Login-Ajax-call" : 'true'
			};

			getUrlRequest.makeHttpCall(url, method, params, headers).then(
					function(resp) {
						vm.response = resp.data;
						if (vm.response.status == "OK") {
							$state.go('login', {}, {
								reload : true
							});
						} else {
							vm.invalidRegistration = true;
							vm.errorMessage = vm.response.message;
						}
					});
		};

	}
	;
})();