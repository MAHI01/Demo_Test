(function(){
	angular.module('Ecommerce').controller('ProductdetailController',ProductdetailController);
	
	ProductdetailController.$inject=['$state','$stateParams','getUrlRequest', '$window'];
	
	function ProductdetailController($state, $stateParams,getUrlRequest, $window){
		var vm=this;
		vm.productDetails='';
		var deviceId = $stateParams.productId;
		var url = "./shop/wireless/devices/details";
		var method= "GET";
		var params = {"deviceId":deviceId};
		getUrlRequest.makeHttpGetCall(url, method, params).then(function(resp){
			vm.productDetails=resp.data;
		});		
		
		vm.addToCart = function(deviceId) {
			var method = 'POST';
			var url = './shop/wireless/devices/cart/addDevice';
			var userId = $window.sessionStorage.getItem("loginUser");
			var params = {
				"deviceId" : deviceId,
				"quantity" : 1,
				"userId" : userId
			};
			getUrlRequest.makeHttpCall(url, method, params).then(
					function(resp) {
						vm.response = resp.data;
						vm.showLoaderIndicator = false;
						/*$state.go('checkout', {
							userId : userId
						});*/
						
						$state.go('checkout');
					});
		};
	};
})();