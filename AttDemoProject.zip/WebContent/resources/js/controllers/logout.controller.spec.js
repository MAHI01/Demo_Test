describe("LogoutController Test", function() {

	var $window, $state;

	var mockedResponse = {
		'userId' : 'userX',
		'A-Token' : 'xxx'
	};

	beforeEach(angular.mock.module("Ecommerce"));

	beforeEach(angular.mock.inject(function(_$window_, _$state_) {
		$window = _$window_;
		$state = _$state_;
		spyOn($state, 'go');
	}));

	beforeEach(inject(function(_$controller_) {
		$controller = _$controller_('LogoutController', {
			$window : $window,
			$state : $state
		});
	}));

	it('should test logout', function() {
		expect($state.go).toHaveBeenCalledWith('login', {
			reload : true
		});

	});

});
