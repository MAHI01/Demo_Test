(function() {
	angular.module('Ecommerce').controller('HomeController', HomeController);

	HomeController.$inject = [ '$window', '$rootScope' ];

	function HomeController($window, $rootScope) {
		vm = this;
		vm.showHeader = true;
		vm.loginHome = $window.sessionStorage.getItem("loginUser");
		$rootScope.$emit("ShowHeader", {});
	}
})();