describe("ProductdetailController Test", function() {

	var $controller, $state, getUrlRequest, $httpBackend, $window;

	var mockedResponse = {
		'userId' : 'userX',
		'A-Token' : 'xxx'
	};

	beforeEach(angular.mock.module("Ecommerce"));

	beforeEach(angular.mock.inject(function(_$state_, _getUrlRequest_,
			_$httpBackend_, _$window_) {
		$state = _$state_;
		getUrlRequest = _getUrlRequest_;
		$httpBackend = _$httpBackend_;
		$window = _$window_;
		spyOn($state, 'go');
	}));

	beforeEach(inject(function(_$controller_) {
		$controller = _$controller_('ProductdetailController', {
			$state : $state,
			getUrlRequest : getUrlRequest,
			$httpBackend : $httpBackend,
			$window : $window
		});
	}));

	afterEach(function() {
		$httpBackend.verifyNoOutstandingExpectation();
		$httpBackend.verifyNoOutstandingRequest();
	});

	it('should fetch device details', function() {
		$httpBackend.when('GET', './shop/wireless/devices/details').respond(
				mockedResponse);

		getUrlRequest
				.makeHttpCall("./shop/wireless/devices/details", "GET", {})
				.then(function(response) {
					expect(response.data.userId).toEqual("userX");
				});
		$httpBackend.flush();
	});

	it('should test addToCart', function() {
		$controller.addToCart("SKU001");

		$httpBackend.when('POST', './shop/wireless/devices/cart/addDevice')
				.respond(mockedResponse);

		getUrlRequest.makeHttpCall("./shop/wireless/devices/cart/addDevice",
				"POST", {}).then(function(response) {
			expect(response.data.userId).toEqual("userX");
			expect($state.go).toHaveBeenCalledWith('checkout');
		});
		$httpBackend.flush();
	});

});