describe("LoginController Test", function() {

	var $controller, $state, getUrlRequest, $httpBackend, $window;

	var mockedResponse = {
		'username' : 'admin'
	};
	
	var mockedResponseFail = {
			'username' : null
		};

	beforeEach(angular.mock.module("Ecommerce"));

	beforeEach(angular.mock.inject(function(_$state_, _getUrlRequest_,
			_$httpBackend_, _$window_, _$rootScope_) {
		$state = _$state_;
		getUrlRequest = _getUrlRequest_;
		$httpBackend = _$httpBackend_;
		$window = _$window_;
		$rootScope = _$rootScope_;
		spyOn($state, 'go');
	}));

	beforeEach(inject(function(_$controller_) {
		$controller = _$controller_('LoginController', {
			$state : $state,
			getUrlRequest : getUrlRequest,
			$httpBackend : $httpBackend,
			$window : $window,
			$rootScope : $rootScope
		});
	}));

	afterEach(function() {
		$httpBackend.verifyNoOutstandingExpectation();
		$httpBackend.verifyNoOutstandingRequest();
	});

	it('should test login', function() {
		$controller.login("username", "password");

		$httpBackend.when('POST', './validateLogin').respond(mockedResponse);

		getUrlRequest.makeHttpCall("./validateLogin", "POST", {}).then(
				function(response) {
					expect(response.data.username).toEqual("admin");
				});
		$httpBackend.flush();
	});
	
	it('should test login fail', function() {
		$controller.login("username", "password");

		$httpBackend.when('POST', './validateLogin').respond(mockedResponseFail);

		getUrlRequest.makeHttpCall("./validateLogin", "POST", {}).then(
				function(response) {
					expect(response.data.username).toEqual(null);
				});
		$httpBackend.flush();
	});

});