describe("HomeController Test", function() {

	var $window, $rootScope;

	var mockedResponse = {
		'userId' : 'userX',
		'A-Token' : 'xxx'
	};

	beforeEach(angular.mock.module("Ecommerce"));

	beforeEach(angular.mock.inject(function(_$window_, _$rootScope_) {
		$window = _$window_;
		$rootScope = _$rootScope_;
	}));

	beforeEach(inject(function(_$controller_) {
		$controller = _$controller_('HomeController', {
			$window : $window,
			$rootScope : $rootScope
		});
	}));

	it('should emit ShowHeader', function() {
		expect($rootScope.$emit("ShowHeader", {}));
	});

});