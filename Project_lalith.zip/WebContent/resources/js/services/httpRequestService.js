(function(){
	angular.module('Ecommerce').service('getUrlRequest',getUrlRequest);
	
	getUrlRequest.$inject=['$http'];
	
	function getUrlRequest($http){
		this.makeHttpCall = function(url, method, params) {
			return $http({
				method : method,
				url : url,
				params : params
			}).then(function successCallback(response) {
				return response;
			}, function errorCallback(response) {
				return response;
			});
		};
	};
})();