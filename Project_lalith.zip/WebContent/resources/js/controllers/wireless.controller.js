(function(){
	angular.module('Ecommerce').controller('WirelessController',WirelessController);
	
	WirelessController.$inject=['$state'];
	
	function WirelessController($state){
		var vm=this;
		vm.checkout=function(id){
			$state.go('checkout', {productId: id});
		};
	};
})();