(function(){
	angular.module('Ecommerce').controller('CheckoutController',CheckoutController);
	
	CheckoutController.$inject=['$stateParams'];
	
	function CheckoutController($stateParams){
		var vm=this;
		vm.imageUrl=$stateParams.productId;
	};
})();