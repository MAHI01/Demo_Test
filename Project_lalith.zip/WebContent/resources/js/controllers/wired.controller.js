(function() {
	angular.module('Ecommerce').controller('WiredController', WiredController);

	WiredController.$inject = [ '$state', 'getUrlRequest', '$http'];

	function WiredController($state, getUrlRequest, $http) {
		var vm = this;
		var method = 'GET';
		var url = './shop/wireless/devices/';
		var params = {};
		getUrlRequest.makeHttpCall(url, method, params).then(function(resp){
			//console.log("data" + JSON.stringify(resp.data));
			vm.response=resp.data;
			console.log("data   " + JSON.stringify(vm.response));
		});
		
		
		vm.deviceDetails = function(deviceId) {
			console.log("deviceId"+deviceId);
			var url = "./shop/wireless/devices/details";
			var method= "GET";
			var params = {"deviceId":deviceId};
			getUrlRequest.makeHttpCall(url, method, params).then(function(resp){
				
			});
		};
		
		vm.checkout = function(id) {
			$state.go('checkout', {
				productId : id
			});
		};
	}
	;
})();