package com.demo.util;

import java.util.ArrayList;
import java.util.List;

import com.demo.att.model.Device;

public class Constants {

	private static final String[] colrsArr1 = { "Midnight Black", "Orchid Gray" };
	private static final String[] colrsArr2 = { "Meteor Gray", "Titanium Gold" };
	private static final String configuration = "32 to 256 GB";

	public static List<Device> getDeviceList() {
		List<Device> deviceList = new ArrayList<Device>();

		Device device1 = new Device();
		device1.setDeviceId("sku001");
		device1.setDesciption("Samsung Galaxy Note8");
		device1.setColors(colrsArr1);
		device1.setConfiguration(configuration);
		device1.setPrice("$31.67/mo.");
		device1.setImgSource("./resources/images/galaxynote8.PNG");

		Device device2 = new Device();
		device2.setDeviceId("sku002");
		device2.setDesciption("Samsung Galaxy S8 Active");
		device2.setColors(colrsArr2);
		device2.setConfiguration(configuration);
		device2.setPrice("$28.34/mo.");
		device2.setImgSource("./resources/images/galaxys8active.PNG");

		deviceList.add(device1);
		deviceList.add(device2);

		return deviceList;

	}

}
