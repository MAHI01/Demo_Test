package com.demo.att.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.att.dao.DeviceDao;
import com.demo.att.model.Device;
import com.demo.att.service.DeviceService;

@Service("deviceService")
public class DeviceServiceImpl implements DeviceService {
	@Autowired
	DeviceDao deviceDao;

	@Override
	public List<Device> getDeviceList() {
		return deviceDao.getDeviceList();
	}

	@Override
	public Device getDeviceDetails(String deviceId) {
		return deviceDao.getDeviceDetails(deviceId);
	}

}
